```dataview  
TABLE  
title as Title,  
FirstAuthor as "First Author",  
Year as Year,  
itemType as Item,  
Citekey as Citekey,  
Contribution as Contribution,  
status as Status
FROM "Literature Notes" and -"Literature Notes/index"
```