# Documents
- [ ] Final version:
- [ ] Drafts:
	1. 
	2. 
	3. 
- [ ] Final docs:

# Info
- *Conference name:* 
- *Language: 
- *Format:*
- *Emal adress:* 
- *Google form:*
- *More info on:* 
- *Authors max:* 
- *% of citations:* <=15%
# Deadlines 
- [ ] *To Write Thesis:* 
- [ ] *To send form with thesis:*
- [ ] *To defend a presentation:* 
# Format 
- *Font-family:* Times New Roman
-  *Paper size:* A4
- *Font-size:* 14
- *Interval:* 1.5
- *Margin:* 2 cm
- *paragraph spacing:* 1.25 cm
- *Language:* English 
- *File name:* 
- *File extension:*
- *Topic:*
- *Volume:*
- *Text alignment:* Justify
- *Citation format:* [APA](http://www.apastyle.org/)
- *Citekey format example:* (Jones, 1998, p. 199)
# Thesis composition
