---
status: unfinished
tags:
  - obsidian
  - test
---
This file contains multiple things I come around while working with Obsidian, use everything found useful!


## Callouts

>[!tip] This
>>[!summary] is 
>>>[!example] just
>>>>[!tldr] good 
>>>>>[!important] looking 
>>>>>>[!warning] test

## Images and captions 
![[Data/Attachments/watermelon_shark.jpg | Nice pet, huh?]]
## LaTeX math 
$$y'=2\,x-4$$
$$y'=6-2\,x$$ 

$$\begin{gathered}y'_{1}=4,y'_{21}=-2\\y'_{21},=-2,y_{22}=4\end{gathered}$$

## Tables 
| Name | Chymotrypsin | Trypsin | Pepsine | Bromocyanide |
| ---- | ---- | ---- | ---- | ---- |
| Amino/Carboxylic group | Carboxylic | Carboxylic | Carboxylic | Carboxylic |
| Which amino acids affects | **Phe, Trp, Tyr** | **Arg, Lys** | **Phe, Trp, Tyr** | **Met** |


## Mermaid diagrams


```mermaid
graph TD
	A[Bacteria] ---> B[Gram-positive]
	A ---> C[Gram-negative]
	B ---> a[Outer membrane]
	B ---> b[Thin peptidoglycan layer]
	B ---> c[Inner membrane]
	C ---> d[Thick peptidoglycan layer]
	C ---> f[Inner membrane]
```

## Chemical structures

>[!important] Enable `Chem` plugin
> You must enable `Chem` from community plugins in the settings to make code below work

```smiles
C1[C@H]2[C@@H]([C@@H](S1)CCCCC(=O)O)NC(=O)N2
```

```smiles
C1=CC(=CC=C1C(=O)N[C@@H](CCC(=O)O)C(=O)O)NCC2=CN=C3C(=N2)C(=O)NC(=N3)N
```

```smiles
CC1=CC2=C(C=C1C)N(C=N2)C3C(C(C(O3)CO)OP(=O)([O-])OC(C)CNC(=O)CCC4(C(C5C6(C(C(C(=N6)C(=C7C(C(C(=N7)C=C8C(C(C(=N8)C(=C4[N-]5)C)CCC(=O)N)(C)C)CCC(=O)N)(C)CC(=O)N)C)CCC(=O)N)(C)CC(=O)N)C)CC(=O)N)C)O.[Co+2]
```