---
citekey: stroganovCOMPARATIVEANALYSISCONVENTIONAL2024
aliases: ["A COMPARATIVE ANALYSIS OF CONVENTIONAL AND MICROALGAE BIOFUELS PRODUCTION"]
title: "A COMPARATIVE ANALYSIS OF CONVENTIONAL AND MICROALGAE BIOFUELS PRODUCTION"
authors: O. Stroganov, M. Rybak, R. Hryhoriev, V. Zhukova
tags: [literature-note, ]
year:  2024 
publisher: "Біотехнологія XXI століття"
status: unread
doi: 
---

> [!Cite]
> Stroganov, O., Rybak, M., Hryhoriev, R., & Zhukova, V. (2024). A COMPARATIVE ANALYSIS OF CONVENTIONAL AND MICROALGAE BIOFUELS PRODUCTION. _Біотехнологія XXI Століття_, 275–278.
  
>[!Synth]  
>**Contribution**::  
>  
>**Related**:: 
>  
  
>[!md]
> **FirstAuthor**:: Stroganov, O.  
> **Author**:: Rybak, M.  
> **Author**:: Hryhoriev, R.  
> **Author**:: Zhukova, V.  
~  
> **Title**:: A COMPARATIVE ANALYSIS OF CONVENTIONAL AND MICROALGAE BIOFUELS PRODUCTION  
> **Year**::  2024   
> **Citekey**:: stroganovCOMPARATIVEANALYSISCONVENTIONAL2024  
> **itemType**:: journalArticle  
> **Journal**::*Біотехнологія XXI століття*  
> **Pages**:: 275–278  
  
> [!LINK]  
>  
> [Stroganov_et_al_2024.pdf](file:///Users/alexeystroganov/.obsidian_vaults/Research/Data/Zotero%20Files/Stroganov_et_al_2024.pdf).  
  
> [!Abstract]  
>.  
>  
# Notes  
>[!notes]
>.  
  
  
# Annotations%% begin annotations %%  
  
  
%% end annotations %%

%% Import Date: 2024-08-04T01:24:23.309+03:00 %%
