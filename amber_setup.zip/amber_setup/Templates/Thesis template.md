---
status: unfinished
published: false
due: 
tags:
  - thesis
  - obsidian
weight:
---

IMRAD format suggestions:: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4404856/

# Introduction 

The _Introduction_ sets the stage for your presentation. It has three parts: what is known, what is unknown, and what your burning question, hypothesis, or aim is. Keep this section short, and write for a general audience (clear, concise, and as nontechnical as you can be)

# Material and methods 

The _Methods_ section gives a clear overview of what you did. Give enough information that your readers can evaluate the persuasiveness of your study. Describe the steps you took, as in a recipe, but be wary of too much detail. If you are doing qualitative research, explain how you picked your subjects to be representative.

# Results 

The _Results_ section summarizes what the data show. Point out relationships, and describe trends. Avoid simply repeating the numbers that are already available in the tables and figures. Data should be restricted to tables as much as possible. Be the friendly narrator, and summarize the tables; do not write the data again in the text.

# Conslusion 

Short but informative summary of your work.

# Discussion (?)

The _Discussion_ section gives you the most freedom. Most authors begin with a brief reiteration of what they did. _Every_ author should restate the key findings and answer the question noted in the _Introduction_. Focus on what your data prove, not what you hoped they would prove. Start with “We found that…” (or something similar), and explain what the data mean. Anticipate your readers' questions, and explain why your results are of interest.

Then compare your results with other people's results. This is where that literature review you did comes in handy. Discuss how your findings support or challenge other studies.

# References 